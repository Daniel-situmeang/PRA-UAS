Michael
191402059
1. Import database quiz_pi ke mysql anda
2. Pastikan username dan password phpmyadmin anda sudah cocok di file koneksi.php 
3. Import file postman_collection.json "NIK-No Telp penduduk API" ke postman anda
4. Extract folder "191402059_Michael_QuizPI" ke XAMPP/htdocs/
5. Jalankan API dengan postman berdasarkan dokumentasi yang sudah dibuat